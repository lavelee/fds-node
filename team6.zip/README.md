# TEAM PROJECT - fastcampus

## Todos
- To make ui kit applied mobile/desktop design
- Marking up HTML
- Styling page
- To receive json by angular
- To send json


### SungHyun's todo
- 


### Doyoung's todo
- To study Angular

## Done
- To setup folder structure
- To select frameworks
